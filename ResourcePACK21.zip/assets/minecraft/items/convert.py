# -*- coding: utf-8 -*-

import json
import sys


def convert_120_to_121(input_path, output_path):
    with open(input_path, "r", encoding="utf-8") as f:
        old = json.load(f)

    overrides = old.get("overrides", [])
    base_item = old.get("textures", {}).get("layer0", "item/diamond_sword")

    cases = []
    seen = set()

    for entry in overrides:
        predicate = entry.get("predicate", {})
        cmd = predicate.get("custom_model_data")
        model_path = entry.get("model")

        if cmd is None or not model_path:
            continue

        # avoid duplicate numeric CMDs
        if cmd in seen:
            continue
        seen.add(cmd)

        cases.append({
            "when": cmd,   # <-- numeric CustomModelData
            "model": {
                "type": "model",
                "model": model_path
            }
        })

    new_format = {
        "model": {
            "type": "select",
            "property": "custom_model_data",
            "fallback": {
                "type": "model",
                "model": base_item
            },
            "cases": cases
        }
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(new_format, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python convert.py old.json new.json")
        sys.exit(1)

    convert_120_to_121(sys.argv[1], sys.argv[2])
