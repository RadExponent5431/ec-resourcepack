# -*- coding: utf-8 -*-

import json
import sys
from pathlib import Path


def convert_120_to_121(input_path, output_path):
    with open(input_path, "r", encoding="utf-8") as f:
        old = json.load(f)

    overrides = old.get("overrides", [])
    base_item = old.get("textures", {}).get("layer0", "item/diamond_sword")

    cases = []
    seen = set()

    for entry in overrides:
        model_path = entry.get("model")
        if not model_path:
            continue

        # use model name (last path segment) as new custom_model_data key
        key = model_path.split("/")[-1]

        # avoid duplicate cases (you have duplicates in your file)
        if key in seen:
            continue
        seen.add(key)

        cases.append({
            "when": key,
            "model": {
                "type": "model",
                "model": model_path
            }
        })

    new_format = {
        "model": {
            "type": "select",
            "property": "custom_model_data",
            "fallback": {
                "type": "model",
                "model": base_item
            },
            "cases": cases
        }
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(new_format, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python convert.py old.json new.json")
        sys.exit(1)

    convert_120_to_121(sys.argv[1], sys.argv[2])
